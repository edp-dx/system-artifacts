# maven-wrapper.properties
## Overview
The 'maven-wrapper.properties' file is used to configure the Maven Wrapper, which is a set of files that includes a small bootstrap script that can be used to invoke a Maven build. The primary purpose of this file is to specify the distribution URL and wrapper URL for the Maven Wrapper.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Useful details](#properties)

## Prerequisites
There are no specific prerequisites for using the 'maven-wrapper.properties' file. However, it is recommended to have Maven installed in the system to utilize the Maven Wrapper.

## Usage
To use the 'maven-wrapper.properties' file in a project, simply place the file in the root directory of the project. The Maven Wrapper will then use the configuration specified in this file to download the specified Maven distribution and wrapper files.

## Useful details
- **distributionUrl** - Specifies the URL for the Maven distribution that the Maven Wrapper should use. For example:
    ```
    distributionUrl=https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/3.9.5/apache-maven-3.9.5-bin.zip
    ```
- **wrapperUrl** - Specifies the URL for the Maven Wrapper JAR file. For example:
    ```
    wrapperUrl=https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.2.0/maven-wrapper-3.2.0.jar
    ```

The provided URLs point to the Maven distribution and Maven Wrapper JAR file hosted on the Apache Maven repository. These URLs can be customized based on the specific version and location of the Maven distribution and wrapper.
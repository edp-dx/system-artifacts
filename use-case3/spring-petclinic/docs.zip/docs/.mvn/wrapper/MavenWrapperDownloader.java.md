# MavenWrapperDownloader.java
## Overview
The `MavenWrapperDownloader.java` file is a Java class that is responsible for downloading the Maven Wrapper for a software project. The Maven Wrapper is a set of files that allow developers to run Maven builds without having to install Maven on their local machines. This class handles the downloading of the Maven Wrapper files and saves them to the appropriate locations in the project.

The primary purpose of this class is to automate the process of downloading and setting up the Maven Wrapper for a project. It ensures that the correct version of the Maven Wrapper is downloaded and saved to the necessary directories.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific prerequisites required to use this file. However, in order to utilize the Maven Wrapper in a project, Maven itself needs to be installed on the machine. The Maven Wrapper acts as a wrapper around the installed Maven, allowing developers to use the project-specific version of Maven without needing to install it globally.

## Usage
To use the `MavenWrapperDownloader` class in a project, follow these steps:

1. Place the `MavenWrapperDownloader.java` file in the desired location within the project's source directory.
2. Compile the Java file using a Java compiler or an IDE.
3. Run the compiled Java class using the `java` command or an IDE.

The class expects a command-line argument for the base directory of the project. This argument specifies the directory where the Maven Wrapper files will be downloaded and saved. Here's an example usage:

```
java MavenWrapperDownloader /path/to/project
```

Replace `/path/to/project` with the actual path to the project's base directory.

## Methods
### `public static void main(String args[])`
The main method of the `MavenWrapperDownloader` class is the entry point for executing the class. It takes a single command-line argument, which is the base directory of the project. The method performs the following steps:

1. Prints a message indicating that the downloader has started.
2. Retrieves the base directory from the command-line arguments.
3. Checks if the `maven-wrapper.properties` file exists in the specified base directory.
4. If the file exists, reads its contents and extracts the `wrapperUrl` property.
5. If the `wrapperUrl` property is found, it is used as the download URL for the Maven Wrapper JAR file. Otherwise, the default download URL is used.
6. Prints the download URL.
7. Creates the necessary directories for saving the Maven Wrapper JAR file.
8. Downloads the Maven Wrapper JAR file from the specified URL and saves it to the appropriate location.
9. Prints a message indicating that the download is complete.
10. Exits the program.

### `private static void downloadFileFromURL(String urlString, File destination) throws Exception`
This method is responsible for downloading a file from a given URL and saving it to a specified destination file. It takes two parameters:

- `urlString` (String): The URL of the file to be downloaded.
- `destination` (File): The file where the downloaded content will be saved.

The method performs the following steps:

1. Checks if environment variables `MVNW_USERNAME` and `MVNW_PASSWORD` are set.
2. If the environment variables are set, it sets up an `Authenticator` with the provided username and password.
3. Creates a `URL` object from the specified URL string.
4. Opens a readable byte channel to the URL's stream.
5. Creates a `FileOutputStream` to the destination file.
6. Transfers the content from the byte channel to the output stream.
7. Closes the output stream and byte channel.

## Useful details
- The `MavenWrapperDownloader` class uses the `java.net` and `java.io` packages for downloading and saving files.
- It also uses the `java.nio.channels` package for efficient file transfer.
- The Maven Wrapper version and default download URL are defined as constants in the class.
- The `maven-wrapper.properties` file can be used to override the default download URL by setting the `wrapperUrl` property.
- The class supports authentication for downloading files if the `MVNW_USERNAME` and `MVNW_PASSWORD` environment variables are set.
- The Maven Wrapper JAR file is saved to the `.mvn/wrapper` directory in the project's base directory.
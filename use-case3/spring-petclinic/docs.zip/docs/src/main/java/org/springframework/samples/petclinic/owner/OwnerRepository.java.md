# OwnerRepository.java
## Overview
This Java interface acts as a repository for the `Owner` domain objects. It provides methods for retrieving, saving, and querying owner data from the data store. It follows Spring Data naming conventions and can easily be extended for Spring Data.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- This file has dependencies on Spring Data and Spring Framework.

## Usage
To use this repository in a project, you can create an instance of it and use its methods to interact with the owner data in the data store.

```java
OwnerRepository ownerRepository = new OwnerRepository();
// Example usage: Find owners by last name
Page<Owner> ownersByLastName = ownerRepository.findByLastName("Smith", PageRequest.of(0, 10));
```

## Methods
1. `findPetTypes()`: Retrieve all pet types from the data store.
   - Returns: a Collection of `PetType`s.
   
2. `findByLastName(String lastName, Pageable pageable)`: Retrieve owners from the data store by last name.
   - Parameters:
     - `lastName`: Value to search for.
     - `pageable`: Pageable object for pagination.
   - Returns: a Collection of matching `Owner`s.

3. `findById(Integer id)`: Retrieve an `Owner` from the data store by id.
   - Parameters:
     - `id`: The id to search for.
   - Returns: the `Owner` if found.
   
4. `save(Owner owner)`: Save an `Owner` to the data store, either inserting or updating it.
   - Parameters:
     - `owner`: The `Owner` to save.
     
5. `findAll(Pageable pageable)`: Returns all the owners from the data store.
   - Parameters:
     - `pageable`: Pageable object for pagination.
   - Returns: a Collection of all `Owner`s.

## Useful details
- This file is compliant with Spring Data naming conventions.
- It depends on Spring Data JPA and Spring Framework.
- It provides methods for querying and saving owner data in the data store.
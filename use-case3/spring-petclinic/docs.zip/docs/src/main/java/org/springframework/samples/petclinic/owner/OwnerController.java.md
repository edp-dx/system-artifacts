# OwnerController.java

## Overview
This file contains the implementation of the `OwnerController` class, which is a controller responsible for handling requests related to owners in a pet clinic application. It provides methods for creating, updating, finding, and displaying owners. The `OwnerController` class interacts with the `OwnerRepository` to perform CRUD operations on owner data.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
No specific prerequisites are mentioned in the file.

## Usage
To use the `OwnerController` class, follow these steps:
1. Instantiate the class and provide an instance of the `OwnerRepository` in the constructor.
2. Use the provided methods to handle owner-related requests:
   - `initCreationForm()`: Initializes the creation form for a new owner.
   - `processCreationForm()`: Processes the form submission for creating a new owner.
   - `initFindForm()`: Initializes the form for finding owners.
   - `processFindForm()`: Processes the form submission for finding owners.
   - `initUpdateOwnerForm()`: Initializes the update form for an existing owner.
   - `processUpdateOwnerForm()`: Processes the form submission for updating an existing owner.
   - `showOwner()`: Displays the details of an owner.
3. Customize the behavior of the `OwnerController` by modifying the implementation of the provided methods or adding new methods as needed.

## Methods
- `setAllowedFields(WebDataBinder dataBinder)`: Sets the fields that are not allowed to be bound during data binding. In this case, the "id" field is disallowed.
- `findOwner(Integer ownerId)`: Returns an instance of the `Owner` class based on the provided owner ID. If no owner ID is provided, a new instance of `Owner` is returned.
- `initCreationForm(Map<String, Object> model)`: Initializes the creation form for a new owner by adding a new instance of `Owner` to the model.
- `processCreationForm(Owner owner, BindingResult result, RedirectAttributes redirectAttributes)`: Processes the form submission for creating a new owner. If there are validation errors, an error message is added to the redirect attributes and the user is redirected back to the creation form. Otherwise, the owner is saved and a success message is added to the redirect attributes.
- `initFindForm()`: Initializes the form for finding owners.
- `processFindForm(int page, Owner owner, BindingResult result, Model model)`: Processes the form submission for finding owners. If no last name is provided, all owners are returned. If owners are found, they are added to the model for display. If only one owner is found, the user is redirected to the details page of that owner. If multiple owners are found, pagination information is added to the model along with the list of owners.
- `addPaginationModel(int page, Model model, Page<Owner> paginated)`: Adds pagination information and the list of owners to the model for display.
- `findPaginatedForOwnersLastName(int page, String lastname)`: Finds owners with the provided last name using pagination. The page number and page size are specified, and a `Pageable` object is used to perform the query.
- `initUpdateOwnerForm(int ownerId, Model model)`: Initializes the update form for an existing owner by adding the owner to the model.
- `processUpdateOwnerForm(Owner owner, BindingResult result, int ownerId, RedirectAttributes redirectAttributes)`: Processes the form submission for updating an existing owner. If there are validation errors, an error message is added to the redirect attributes and the user is redirected back to the update form. Otherwise, the owner is updated and a success message is added to the redirect attributes.
- `showOwner(int ownerId)`: Displays the details of an owner. The owner is retrieved based on the provided owner ID, and the owner object is added to the model for display.

## Useful details
- Frameworks and dependencies mentioned in the file: Spring Framework
- No additional details are mentioned in the file.
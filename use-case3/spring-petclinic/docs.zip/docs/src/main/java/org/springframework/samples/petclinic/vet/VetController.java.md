# VetController.java
## Overview
The `VetController` is a Java class that serves as a controller for handling vet-related requests in a software project. It is responsible for handling requests related to displaying a list of vets, and provides methods for paginating and retrieving vet data.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- Spring Framework
- VetRepository

## Usage
To use the `VetController` in a project, it needs to be instantiated and used to handle vet-related requests. An instance of `VetRepository` also needs to be provided as a dependency for the controller.

```java
VetRepository vetRepository = // instantiate VetRepository
VetController vetController = new VetController(vetRepository);
```

## Methods
### showVetList
```java
public String showVetList(@RequestParam(defaultValue = "1") int page, Model model)
```
This method is responsible for displaying a paginated list of vets. It takes a page number and a Model as parameters, and returns the view for the vet list.

### addPaginationModel
```java
private String addPaginationModel(int page, Page<Vet> paginated, Model model)
```
This method adds pagination-related attributes to the model for displaying the vet list.

### findPaginated
```java
private Page<Vet> findPaginated(int page)
```
This method retrieves paginated vet data from the `VetRepository` based on the given page number.

### showResourcesVetList
```java
public @ResponseBody Vets showResourcesVetList()
```
This method is responsible for returning a list of vets as a JSON response. It returns an object of type 'Vets' containing the vet list.

## Useful details
- The controller uses Spring's `@Controller` and `@GetMapping` annotations to handle requests.
- It utilizes `VetRepository` for retrieving vet data.
- Pagination is implemented for displaying the list of vets.
# Owner.java
## Overview
`Owner.java` is a Java class that represents an owner in a pet clinic management system. It is a domain object that extends the `Person` class and contains information about the owner's address, city, telephone number, and the pets they own. The class provides methods to manipulate and access this information, such as adding a pet, retrieving a pet by name or ID, and adding a visit for a pet.

This class is an essential component of the pet clinic management system as it encapsulates the data and behavior of an owner. It allows the system to store and retrieve information about owners and their pets, facilitating various operations in the larger project, such as creating appointments, managing medical records, and generating reports.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific prerequisites for using `Owner.java`. However, it is assumed that the project is using Java and a compatible development environment.

## Usage
To use `Owner.java` in a project, follow these steps:

1. Import the necessary classes and packages:
```java
import org.springframework.samples.petclinic.owner.Owner;
import org.springframework.samples.petclinic.owner.Pet;
import org.springframework.samples.petclinic.owner.Visit;
```

2. Create an instance of the `Owner` class:
```java
Owner owner = new Owner();
```

3. Set the owner's information such as address, city, and telephone number:
```java
owner.setAddress("123 Main St");
owner.setCity("New York");
owner.setTelephone("555-1234");
```

4. Add pets to the owner's list of pets:
```java
Pet pet1 = new Pet();
pet1.setName("Max");
owner.addPet(pet1);

Pet pet2 = new Pet();
pet2.setName("Bella");
owner.addPet(pet2);
```

5. Perform operations on the owner's pets, such as adding a visit:
```java
Visit visit = new Visit();
// Set visit details

owner.addVisit(pet1.getId(), visit);
```

## Methods
### `getAddress()`
```java
public String getAddress()
```
Returns the address of the owner.

### `setAddress(String address)`
```java
public void setAddress(String address)
```
Sets the address of the owner.

### `getCity()`
```java
public String getCity()
```
Returns the city of the owner.

### `setCity(String city)`
```java
public void setCity(String city)
```
Sets the city of the owner.

### `getTelephone()`
```java
public String getTelephone()
```
Returns the telephone number of the owner.

### `setTelephone(String telephone)`
```java
public void setTelephone(String telephone)
```
Sets the telephone number of the owner.

### `getPets()`
```java
public List<Pet> getPets()
```
Returns a list of pets owned by the owner.

### `addPet(Pet pet)`
```java
public void addPet(Pet pet)
```
Adds a pet to the owner's list of pets.

### `getPet(String name)`
```java
public Pet getPet(String name)
```
Returns the pet with the given name, or null if none is found for this owner.

### `getPet(Integer id)`
```java
public Pet getPet(Integer id)
```
Returns the pet with the given ID, or null if none is found for this owner.

### `getPet(String name, boolean ignoreNew)`
```java
public Pet getPet(String name, boolean ignoreNew)
```
Returns the pet with the given name, ignoring new pets if specified.

### `toString()`
```java
@Override
public String toString()
```
Returns a string representation of the owner, including their ID, last name, first name, address, city, and telephone number.

### `addVisit(Integer petId, Visit visit)`
```java
public void addVisit(Integer petId, Visit visit)
```
Adds the given visit to the pet with the given ID.

## Useful details
- This class is part of the `org.springframework.samples.petclinic.owner` package.
- It extends the `Person` class, which is likely to be another domain object representing a person.
- The class uses annotations from the `jakarta.persistence` package for mapping to a database table.
- It also uses annotations from the `jakarta.validation.constraints` package for validating input fields.
- The class depends on the `Pet` and `Visit` classes, which are likely to be other domain objects in the pet clinic management system.
- The class includes several utility methods for managing pets and visits, such as retrieving pets by name or ID and adding visits to pets.
# Vet.java
## Overview
The Vet.java file is a Java class that represents a veterinarian in a pet clinic management system. It extends the `Person` class and includes functionalities related to managing specialties and details of veterinarians.
## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)
## Prerequisites
No specific prerequisites are mentioned in the file.
## Usage
To use the `Vet` class in a project, you can instantiate it as follows:
```java
Vet vet = new Vet();
```
You can then utilize the methods and properties of the `Vet` class to manage specialties and other details related to a veterinarian.
## Methods
- `getSpecialtiesInternal()`: Protected method that returns the internal set of specialties.
- `setSpecialtiesInternal(Set<Specialty> specialties)`: Protected method to set the internal set of specialties.
- `getSpecialties()`: Public method that returns a sorted list of specialties.
- `getNrOfSpecialties()`: Public method to get the number of specialties for the veterinarian.
- `addSpecialty(Specialty specialty)`: Public method to add a specialty to the veterinarian's list of specialties.

## Useful details
- Frameworks: The class uses `jakarta.persistence` annotations for entity and table management.
- Dependencies: It has a dependency on the `Specialty` class.
# CrashController.java
## Overview
The `CrashController.java` file is a controller class that is used to showcase what happens when an exception is thrown in a Spring Boot web application. It includes a method to trigger an exception and a corresponding endpoint to handle the exception.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use the `CrashController.java` file.

## Usage
To utilize the `CrashController` in a Spring Boot web project, follow these steps:
1. Import the necessary classes:
   ```java
   import org.springframework.stereotype.Controller;
   import org.springframework.web.bind.annotation.GetMapping;
   ```
2. Create an instance of `CrashController` or utilize it through dependency injection.

## Methods
### `triggerException()`
```java
@GetMapping("/oups")
public String triggerException() {
    throw new RuntimeException("Expected: controller used to showcase what happens when an exception is thrown");
}
```
This method is mapped to the `/oups` endpoint and is used to trigger an exception. When called, it throws a `RuntimeException` with a specific error message.

## Useful details
- This file is part of the `org.springframework.samples.petclinic.system` package.
- It is licensed under the Apache License, Version 2.0.
- The controller includes a single method to trigger an exception, which can be useful for testing error handling and logging in a Spring Boot application.
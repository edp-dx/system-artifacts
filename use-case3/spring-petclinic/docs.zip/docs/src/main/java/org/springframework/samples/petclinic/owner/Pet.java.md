# Pet.java
## Overview
The `Pet.java` file contains the code for a simple business object representing a pet. It includes properties for the pet's birth date, type, and a collection of visits. The class plays a crucial role in the Pet Clinic software project as it represents the core entity of the system - a pet.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file.

## Usage
To utilize the `Pet` class in a project, follow these steps:
1. Import the `Pet.java` file into the project.
2. Instantiate a new `Pet` object and set its properties as needed.
3. Utilize the various methods available for setting and getting the pet's birth date, type, and visits.

Example:
```java
Pet myPet = new Pet();
myPet.setBirthDate(LocalDate.of(2015, 5, 15));
myPet.setType(petType);
myPet.addVisit(visit);
```

## Methods
The `Pet.java` file contains the following methods:
- `setBirthDate(LocalDate birthDate)`: Sets the birth date of the pet.
- `getBirthDate()`: Retrieves the birth date of the pet.
- `getType()`: Retrieves the type of the pet.
- `setType(PetType type)`: Sets the type of the pet.
- `getVisits()`: Retrieves the collection of visits for the pet.
- `addVisit(Visit visit)`: Adds a visit to the collection of visits for the pet.

## Useful details
- The file uses the `LocalDate` class for representing birth date.
- It utilizes the `PetType` and `Visit` classes, which are assumed to be defined elsewhere in the project.
- The class is annotated with various `jakarta.persistence` annotations for defining the entity, table, and relationships with other entities.
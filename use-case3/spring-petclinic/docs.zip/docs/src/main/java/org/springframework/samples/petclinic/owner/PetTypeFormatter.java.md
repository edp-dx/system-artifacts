# PetTypeFormatter.java
## Overview
The `PetTypeFormatter` class is a component of the Spring PetClinic project and is responsible for instructing Spring MVC on how to parse and print elements of type 'PetType'. It utilizes the Formatter interface to provide parsing and printing functionality for PetType objects.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
No specific dependencies or prerequisites are required to use this file other than having the Spring framework available.

## Usage
To use the `PetTypeFormatter` class in a project, it can be instantiated and utilized in conjunction with Spring MVC to handle the parsing and printing of PetType objects.

## Methods
### `print(PetType petType, Locale locale)`
Prints the string representation of the provided PetType object based on the specified locale.

- `petType`: The PetType object to be printed.
- `locale`: The locale for which the PetType should be printed.

### `parse(String text, Locale locale)`
Parses the input string to find the corresponding PetType object based on the specified locale.

- `text`: The input string representing the PetType.
- `locale`: The locale in which the input string should be parsed.

## Useful details
- Version: 2012-2019
- Framework: Spring
- Dependencies: OwnerRepository

The class provides functionality for parsing and printing PetType objects within the Spring PetClinic project. It implements the Formatter interface and utilizes an Autowired OwnerRepository to retrieve and manipulate PetType objects. The class is also annotated as a Spring Component, indicating its role within the Spring application context.
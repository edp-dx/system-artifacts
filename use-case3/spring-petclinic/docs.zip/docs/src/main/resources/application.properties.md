# application.properties
## Overview
The `application.properties` file is a configuration file used in a Java Spring project. It contains key-value pairs that configure various aspects of the application, such as the database, web settings, JPA, internationalization, actuator, logging, and resource caching. This file plays a crucial role in defining the behavior and settings of the application.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file. However, the application itself may have dependencies on Spring, Hibernate, and other related frameworks.

## Usage
To use the `application.properties` file, it should be located in the `src/main/resources` directory of the Java project. The configuration properties defined in this file will be automatically picked up by the Spring application context during startup. Developers can modify the values of the properties to customize the behavior of the application.

## Useful details
- `database`: Specifies the database being used (in this case, it is set to H2, but it also supports MySQL).
- `spring.sql.init.schema-locations` and `spring.sql.init.data-locations`: Define the locations of the schema and data SQL files for database initialization.
- `spring.thymeleaf.mode`: Sets the mode for Thymeleaf, a popular Java templating engine often used for web applications.
- `spring.jpa.hibernate.ddl-auto`: Configures the behavior of Hibernate's DDL generation.
- `spring.jpa.open-in-view`: Controls whether to register OpenEntityManagerInViewInterceptor.
- `spring.messages.basename`: Defines the base name for the message properties files for internationalization.
- `management.endpoints.web.exposure.include`: Specifies which endpoints are exposed by the actuator.
- `logging.level`: Configures the logging levels for various packages.
- `spring.web.resources.cache.cachecontrol.max-age`: Sets the maximum time static resources should be cached.

This file provides a centralized location to configure various aspects of the application, making it easier to manage and maintain the project.
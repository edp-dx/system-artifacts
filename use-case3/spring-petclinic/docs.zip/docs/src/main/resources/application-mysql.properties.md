# application-mysql.properties
## Overview
The 'application-mysql.properties' file is used to configure the database settings for a software project, specifically for MySQL. It includes properties for the database connection URL, username, password, and SQL initialization mode.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file, other than having a MySQL database server available.

## Usage
To use the 'application-mysql.properties' file in a project, you can include it in the project's configuration directory. The properties can be customized by setting environment variables or directly modifying the file. Here's an example of how to configure the MySQL database settings using this file in a Spring Boot application:

```java
@SpringBootApplication
@PropertySource("classpath:application-mysql.properties")
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

## Methods
The file does not contain any methods or functions. It simply includes key-value pairs for configuring the MySQL database connection.

## Useful details
- The file specifies the database type as 'mysql' using the 'database' property.
- It sets the database connection URL, username, and password using the 'spring.datasource.url', 'spring.datasource.username', and 'spring.datasource.password' properties respectively.
- The SQL initialization mode is set to 'always' using the 'spring.sql.init.mode' property, which means that the SQL scripts will be executed every time the application starts.

This file is essential for configuring the MySQL database connection in a Spring Boot application and plays a crucial role in defining the database settings for the project.
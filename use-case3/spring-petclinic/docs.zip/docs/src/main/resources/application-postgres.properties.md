# application-postgres.properties
## Overview
The `application-postgres.properties` file is used to configure the PostgreSQL database connection for a software project. It includes properties for the database URL, username, password, and SQL initialization mode.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file other than having a PostgreSQL database available.

## Usage
To use the `application-postgres.properties` file in a project, simply include it in the project's configuration or properties folder. The properties defined in this file will be used by the application to establish a connection to the PostgreSQL database.

## Useful details
- `database`: Specifies the database type, in this case, it is set to `postgres`.
- `spring.datasource.url`: Specifies the URL for the PostgreSQL database. It is set to `jdbc:postgresql://localhost/petclinic`, with the option to override it using the `POSTGRES_URL` environment variable.
- `spring.datasource.username`: Specifies the username for the PostgreSQL database. It is set to `petclinic`, with the option to override it using the `POSTGRES_USER` environment variable.
- `spring.datasource.password`: Specifies the password for the PostgreSQL database. It is set to `petclinic`, with the option to override it using the `POSTGRES_PASS` environment variable.
- `spring.sql.init.mode`: Specifies the SQL initialization mode for the application. It is set to `always`, indicating that SQL initialization should always be performed.

The properties in this file can be customized as needed for different environments or configurations. For example, the database URL, username, and password can be overridden using environment variables to ensure flexibility and security in different deployment scenarios.
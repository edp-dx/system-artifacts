# CrashControllerIntegrationTests.java
## Overview
This Java class serves as an Integration Test for the CrashController. It contains test cases for triggering exceptions in both JSON and HTML formats.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- This file has dependencies on Spring Boot and Spring Framework.
- Requires access to a server with the specified port.

## Usage
To use this file in a project:
- Ensure that the project has the necessary dependencies on Spring Boot and Spring Framework.
- Instantiate the CrashControllerIntegrationTests class and run the test methods.

## Methods
- `testTriggerExceptionJson()`: Sends an HTTP request to trigger an exception in JSON format and asserts the response.
- `testTriggerExceptionHtml()`: Sends an HTTP request to trigger an exception in HTML format and asserts the response.

## Useful details
- The class is annotated with `@SpringBootTest` which sets the web environment to RANDOM_PORT and includes specific properties.
- It uses `TestRestTemplate` for making HTTP requests and handling responses.
- It contains a nested class `TestConfiguration` for configuring the application context during testing.
- Utilizes various Spring annotations such as `@Autowired` and `@Value` for dependency injection and property configuration.
- Excludes specific auto-configurations using the `@SpringBootApplication` annotation in the `TestConfiguration` class.
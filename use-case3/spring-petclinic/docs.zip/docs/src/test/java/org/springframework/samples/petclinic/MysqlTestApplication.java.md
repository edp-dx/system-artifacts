# MysqlTestApplication.java
## Overview
The `MysqlTestApplication` Java class is a configuration file for the PetClinic Spring Boot Application. It includes a method to instantiate a MySQLContainer for testing purposes and a main method to run the Spring application with a MySQL profile.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- Spring Boot framework
- Testcontainers library

## Usage
To use the `MysqlTestApplication` class in a project, you need to have the Spring Boot framework and the Testcontainers library included in your project dependencies. You can then instantiate the `MySQLContainer` by calling the `container()` method and use the `main()` method to run the Spring application with the MySQL profile active.

```java
MySQLContainer<?> mysqlContainer = MysqlTestApplication.container();
mysqlContainer.start();
// Other application setup code
MysqlTestApplication.main(new String[]{"--spring.profiles.active=mysql"});
```

## Methods
### `container()`
- **Description**: Returns a new instance of `MySQLContainer` configured for MySQL 8.2.
- **Return Type**: `MySQLContainer<?>`
- **Parameters**: None
- **Example**:
```java
MySQLContainer<?> mysqlContainer = MysqlTestApplication.container();
mysqlContainer.start();
```

### `main(String[] args)`
- **Description**: Runs the Spring Boot application with the MySQL profile active.
- **Parameters**:
  - `args` - Command line arguments
- **Example**:
```java
MysqlTestApplication.main(new String[]{"--spring.profiles.active=mysql"});
```

## Useful details
- Framework: Spring Boot
- Dependencies: Testcontainers library
- MySQLContainer version: 8.2
# PetClinicIntegrationTests.java
## Overview
This Java class is part of the PetClinic application and serves as the integration test suite for testing the functionality of the application in a real-world environment. It includes tests for finding all vets and retrieving owner details from the application's REST API.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- This file requires the following dependencies:
  - Spring Boot
  - JUnit 5
  - RestTemplate

## Usage
To use this class in a project, follow these steps:
1. Ensure that the project has the necessary dependencies listed in the prerequisites.
2. Instantiate the PetClinicIntegrationTests class within the test package of the project.
3. Run the tests using an appropriate testing framework (e.g., JUnit).

## Methods
- `testFindAll()`: Method to test the functionality of finding all vets. It calls the `vets.findAll()` method and verifies that the result is served from the cache.
- `testOwnerDetails()`: Method to test the retrieval of owner details from the application's REST API. It sends a request to retrieve owner details and verifies that the response status is OK.

## Useful details
- This file is using Spring Boot's `@SpringBootTest` annotation with `WebEnvironment.RANDOM_PORT` for integration testing.
- It utilizes the `LocalServerPort` annotation to inject a random port for testing.
- The `VetRepository` and `RestTemplateBuilder` are autowired for use in the test methods.
# PostgresIntegrationTests.java

## Overview
`PostgresIntegrationTests.java` is a Java class that contains integration tests for the Postgres database integration in the PetClinic application. It tests various functionalities and interactions with the database, such as retrieving all vets and owner details. This class plays a role in ensuring the correct functioning and integration of the Postgres database with the PetClinic application.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
To use `PostgresIntegrationTests.java`, the following dependencies are required:
- Apache Commons Logging
- JUnit Jupiter
- AssertJ
- Spring Boot Test
- Spring Web
- Testcontainers
- Docker

## Usage
To use `PostgresIntegrationTests.java` in a project, follow these steps:
1. Ensure that all the required dependencies are included in the project.
2. Create a new instance of `PostgresIntegrationTests` or use dependency injection to obtain an instance.
3. Run the integration tests using a testing framework, such as JUnit.

## Methods
The following methods are available in `PostgresIntegrationTests.java`:

### `main(String[] args)`
This method is the entry point for running the PetClinic application with the Postgres profile. It starts the application and sets the active profiles to "postgres". It also configures a listener to log the application's properties.

Example:
```java
public static void main(String[] args) {
    new SpringApplicationBuilder(PetClinicApplication.class)
        .profiles("postgres")
        .properties("spring.docker.compose.profiles.active=postgres")
        .listeners(new PropertiesLogger())
        .run(args);
}
```

### `testFindAll()`
This method tests the functionality of retrieving all vets from the database. It calls the `findAll()` method of the `VetRepository` and asserts that the result is not null.

Example:
```java
@Test
void testFindAll() throws Exception {
    vets.findAll();
    vets.findAll(); // served from cache
}
```

### `testOwnerDetails()`
This method tests the functionality of retrieving owner details from the PetClinic application's REST API. It sends a GET request to the "/owners/{ownerId}" endpoint and asserts that the response status is OK.

Example:
```java
@Test
void testOwnerDetails() {
    RestTemplate template = builder.rootUri("http://localhost:" + port).build();
    ResponseEntity<String> result = template.exchange(RequestEntity.get("/owners/1").build(), String.class);
    assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
}
```

## Useful details
- This class requires Docker to be available in order to run the integration tests.
- The `@SpringBootTest` annotation is used to configure the integration tests. It sets the web environment to RANDOM_PORT and specifies the "postgres" profile.
- The `@DisabledInNativeImage` annotation indicates that the integration tests should be disabled in a native image environment.
- The `PropertiesLogger` class is an application listener that logs the properties of the application's environment.
- The `printProperties()` method prints the properties of the environment, including any overridden values.
- The `findPropertiesPropertySources()` method finds the property sources in the environment that are enumerable.
- The `PostgresIntegrationTests` class uses autowiring to inject the `VetRepository` and `RestTemplateBuilder` dependencies.
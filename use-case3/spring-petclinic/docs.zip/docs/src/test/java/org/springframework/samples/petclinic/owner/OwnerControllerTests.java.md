# OwnerControllerTests.java
## Overview
The `OwnerControllerTests.java` file is a test class for the `OwnerController` in a pet clinic software project. It contains various test cases to ensure the correct behavior of the `OwnerController` class.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
No specific prerequisites or dependencies are mentioned in the file.

## Usage
To use this test class in a project, follow these steps:
1. Ensure that the required dependencies are included in the project.
2. Instantiate the `OwnerControllerTests` class.
3. Run the desired test methods to verify the functionality of the `OwnerController`.

## Methods
The `OwnerControllerTests` class contains the following methods:

### `setup()`
This method is executed before each test case. It sets up mock data and behaviors using Mockito.

### `testInitCreationForm()`
This method tests the initialization of the creation form for a new owner. It sends a GET request to the "/owners/new" endpoint and expects a successful response with the "createOrUpdateOwnerForm" view.

### `testProcessCreationFormSuccess()`
This method tests the successful processing of the creation form for a new owner. It sends a POST request to the "/owners/new" endpoint with the required parameters and expects a redirection response.

### `testProcessCreationFormHasErrors()`
This method tests the processing of the creation form for a new owner with errors. It sends a POST request to the "/owners/new" endpoint with missing parameters and expects an error response with the "createOrUpdateOwnerForm" view.

### `testInitFindForm()`
This method tests the initialization of the find form for owners. It sends a GET request to the "/owners/find" endpoint and expects a successful response with the "findOwners" view.

### `testProcessFindFormSuccess()`
This method tests the successful processing of the find form for owners. It sends a GET request to the "/owners?page=1" endpoint and expects a successful response with the "ownersList" view.

### `testProcessFindFormByLastName()`
This method tests the processing of the find form for owners by last name. It sends a GET request to the "/owners?page=1" endpoint with a specific last name parameter and expects a redirection response to the owner details page.

### `testProcessFindFormNoOwnersFound()`
This method tests the processing of the find form for owners when no owners are found. It sends a GET request to the "/owners?page=1" endpoint with an unknown last name parameter and expects an error response with the "findOwners" view.

### `testInitUpdateOwnerForm()`
This method tests the initialization of the update owner form. It sends a GET request to the "/owners/{ownerId}/edit" endpoint with a specific owner ID and expects a successful response with the "createOrUpdateOwnerForm" view.

### `testProcessUpdateOwnerFormSuccess()`
This method tests the successful processing of the update owner form. It sends a POST request to the "/owners/{ownerId}/edit" endpoint with the required parameters and expects a redirection response.

### `testProcessUpdateOwnerFormUnchangedSuccess()`
This method tests the successful processing of the update owner form when no changes are made. It sends a POST request to the "/owners/{ownerId}/edit" endpoint without any parameters and expects a redirection response.

### `testProcessUpdateOwnerFormHasErrors()`
This method tests the processing of the update owner form with errors. It sends a POST request to the "/owners/{ownerId}/edit" endpoint with missing parameters and expects an error response with the "createOrUpdateOwnerForm" view.

### `testShowOwner()`
This method tests the retrieval of owner details. It sends a GET request to the "/owners/{ownerId}" endpoint with a specific owner ID and expects a successful response with the owner details and associated pets.

## Useful details
- Framework: Spring Boot
- Dependencies: Mockito, Hamcrest, AssertJ
- Version: 2012-2019
- License: Apache License, Version 2.0
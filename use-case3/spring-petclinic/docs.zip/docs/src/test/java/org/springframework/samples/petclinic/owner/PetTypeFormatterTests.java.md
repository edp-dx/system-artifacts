# PetTypeFormatterTests.java
## Overview
This file contains the unit tests for the `PetTypeFormatter` class, which is responsible for formatting and parsing `PetType` objects. The tests cover the print and parse functionality of the `PetTypeFormatter` class.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file.

## Usage
To use the `PetTypeFormatterTests` in a project, you can simply include this file in the test suite. The tests are designed to be run using a testing framework such as JUnit.

## Methods
- `setup()`: Initializes the `PetTypeFormatter` instance before each test.
- `testPrint()`: Tests the print functionality of the `PetTypeFormatter` class.
- `shouldParse()`: Tests the parse functionality of the `PetTypeFormatter` class.
- `shouldThrowParseException()`: Tests the scenario where a parse exception should be thrown.
- `makePetTypes()`: Helper method to produce sample pet types for testing purposes.

## Useful details
- This file is using JUnit 5 for writing unit tests.
- It uses Mockito for mocking the `OwnerRepository` dependency.
- The `PetTypeFormatter` class is being tested for its print and parse functionality using sample pet types.
# VetControllerTests.java
## Overview
The VetControllerTests.java file is a test class for the VetController. It contains test methods for the VetController class to ensure its functionality in a software project.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- Dependencies:
  - Spring Boot
  - JUnit 5
  - MockMvc
  - Mockito

## Usage
To utilize the VetControllerTests class in a project, follow these steps:
1. Ensure that the project includes the required dependencies listed in the prerequisites section.
2. Instantiate the VetControllerTests class.
3. Run the test methods to validate the functionality of the VetController.

## Methods
The VetControllerTests class contains the following test methods:
1. `testShowVetListHtml()`: Tests the display of vet list in HTML format.
   - Parameters: None
   - Returns: None
   - Example:
     ```java
     @Test
     void testShowVetListHtml() throws Exception {
         mockMvc.perform(MockMvcRequestBuilders.get("/vets.html?page=1"))
             .andExpect(status().isOk())
             .andExpect(model().attributeExists("listVets"))
             .andExpect(view().name("vets/vetList"));
     }
     ```

2. `testShowResourcesVetList()`: Tests the display of vet list in JSON format.
   - Parameters: None
   - Returns: None
   - Example:
     ```java
     @Test
     void testShowResourcesVetList() throws Exception {
         ResultActions actions = mockMvc.perform(get("/vets").accept(MediaType.APPLICATION_JSON))
             .andExpect(status().isOk());
         actions.andExpect(content().contentType(MediaType.APPLICATION_JSON))
             .andExpect(jsonPath("$.vetList[0].id").value(1));
     }
     ```

## Useful details
- Framework: Spring Boot
- Test Annotations: @WebMvcTest, @DisabledInNativeImage, @DisabledInAotMode
- Dependencies: VetRepository, MockMvc, MediaType
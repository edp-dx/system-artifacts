# ClinicServiceTests.java
## Overview
This Java class is responsible for performing integration tests on the Service and Repository layers of the software project. It tests the functionalities of the clinic service using the Spring TestContext Framework. The class ensures that the service and repository components are working correctly and are able to interact with the database.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- This class requires the Spring TestContext Framework.
- It also requires the Spring Data JPA framework.

## Usage
To use this class in a project:
1. Make sure the project has the necessary dependencies mentioned in the Prerequisites section.
2. Instantiate an object of the ClinicServiceTests class.
3. Use the various test methods provided in the class to test the functionalities of the clinic service.

Example:
```java
ClinicServiceTests clinicServiceTests = new ClinicServiceTests();
clinicServiceTests.shouldFindOwnersByLastName();
```

## Methods
1. `shouldFindOwnersByLastName()`: This method tests the functionality of finding owners by their last name. It verifies that the correct number of owners is returned based on the last name provided as a parameter.

2. `shouldFindSingleOwnerWithPet()`: This method tests the functionality of finding a single owner with their pet. It verifies that the owner's last name, the number of pets, and the type of the pet are correct.

3. `shouldInsertOwner()`: This method tests the functionality of inserting a new owner into the database. It verifies that the owner is saved successfully and has a generated ID.

4. `shouldUpdateOwner()`: This method tests the functionality of updating an existing owner's last name. It verifies that the owner's last name is updated correctly in the database.

5. `shouldFindAllPetTypes()`: This method tests the functionality of finding all pet types. It verifies that the correct pet types are returned from the database.

6. `shouldInsertPetIntoDatabaseAndGenerateId()`: This method tests the functionality of inserting a new pet into the database. It verifies that the pet is saved successfully and has a generated ID.

7. `shouldUpdatePetName()`: This method tests the functionality of updating an existing pet's name. It verifies that the pet's name is updated correctly in the database.

8. `shouldFindVets()`: This method tests the functionality of finding all vets. It verifies that the correct vets are returned from the database.

9. `shouldAddNewVisitForPet()`: This method tests the functionality of adding a new visit for a pet. It verifies that the visit is added successfully and has a generated ID.

10. `shouldFindVisitsByPetId()`: This method tests the functionality of finding visits by pet ID. It verifies that the correct visits are returned for the given pet ID.

## Useful details
- This class is an integration test and is used to test the integration of the Service and Repository layers of the software project.
- It is annotated with the `@DataJpaTest` annotation to enable testing with the Spring Data JPA framework.
- It is also annotated with the `@AutoConfigureTestDatabase` annotation to configure the test database. The `Replace.NONE` option ensures that the real database is used instead of an in-memory database.
- The class includes dependencies on the `OwnerRepository` and `VetRepository` interfaces, which are used to interact with the database.
- The class includes various test methods that test different functionalities of the clinic service, such as finding owners, pets, vets, and visits, as well as inserting and updating owners and pets.
- The test methods are annotated with the `@Test` annotation to indicate that they are test methods.
- The class also includes some utility methods and variables for testing purposes.
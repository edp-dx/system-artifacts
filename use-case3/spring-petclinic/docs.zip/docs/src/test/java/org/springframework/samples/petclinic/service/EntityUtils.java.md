# EntityUtils.java
## Overview
The EntityUtils.java file contains utility methods for handling entities in a software project. It is separate from the BaseEntity class due to its dependency on the ORM-associated ObjectRetrievalFailureException. This file provides a method to look up an entity of a given class with a given id in a collection.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file.

## Usage
To utilize the EntityUtils class in a project, it can be instantiated and used to look up entities in a collection using the provided method.

```java
Collection<BaseEntity> entities = // populate collection with entities
EntityUtils.getById(entities, BaseEntity.class, entityId);
```

## Methods
### getById
```java
public static <T extends BaseEntity> T getById(Collection<T> entities, Class<T> entityClass, int entityId)
        throws ObjectRetrievalFailureException
```
Look up the entity of the given class with the given id in the given collection.
- Parameters:
  - entities: the collection to search
  - entityClass: the entity class to look up
  - entityId: the entity id to look up
- Returns:
  - The found entity
- Throws:
  - ObjectRetrievalFailureException: if the entity was not found

## Useful details
- Version: 29.10.2003
- Frameworks: Spring Framework
- Dependencies: Spring ORM, ObjectRetrievalFailureException
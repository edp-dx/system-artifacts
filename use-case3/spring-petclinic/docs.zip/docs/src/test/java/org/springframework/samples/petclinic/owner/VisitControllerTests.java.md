# VisitControllerTests.java
## Overview
The `VisitControllerTests.java` file contains the test class for the `VisitController` in the `org.springframework.samples.petclinic.owner` package. It includes tests for initializing a new visit form, processing a new visit form with success, and processing a new visit form that has errors. This file is a part of the larger Spring PetClinic software project and is responsible for testing the functionality of the `VisitController` class.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- Java 8 or higher
- Spring Boot
- JUnit 5
- Mockito
- MockMvc
- OwnerRepository

## Usage
To use the `VisitControllerTests` class in a project, follow these steps:
1. Import the required packages:
   ```java
   import org.junit.jupiter.api.Test;
   import org.springframework.beans.factory.annotation.Autowired;
   import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
   import org.springframework.boot.test.mock.mockito.MockBean;
   import org.springframework.test.context.aot.DisabledInAotMode;
   import org.springframework.test.web.servlet.MockMvc;
   ```

2. Ensure that the `OwnerRepository` is available.

3. Use the `@WebMvcTest` annotation to test the `VisitController`:
   ```java
   @WebMvcTest(VisitController.class)
   ```

## Methods
- `init()`: Initializes an `Owner` and a `Pet` and sets up a mock response using the `owners` repository.
- `testInitNewVisitForm()`: Tests the initialization of a new visit form by performing a GET request and expecting a specific view name.
- `testProcessNewVisitFormSuccess()`: Tests the processing of a new visit form with success by performing a POST request with parameters and expecting a redirection to a specific view.
- `testProcessNewVisitFormHasErrors()`: Tests the processing of a new visit form that has errors by performing a POST request with incorrect parameters and expecting specific attributes and view name.

## Useful details
- Spring Boot test annotations (`@WebMvcTest`, `@MockBean`, etc.) are used for testing the `VisitController`.
- The `MockMvc` instance is autowired for performing mock HTTP requests and verifying responses.
- The tests are written using JUnit 5 and utilize the Mockito framework for mocking dependencies.
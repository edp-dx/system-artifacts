# CrashControllerTests.java
## Overview
The `CrashControllerTests` Java class is a test class for the `CrashController`. It is responsible for testing the functionality of the `CrashController` class by triggering an exception and verifying the expected behavior.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file.

## Usage
To use the `CrashControllerTests` class in a project, you can create an instance of the class and run the test methods to verify the behavior of the `CrashController` class.

```java
CrashControllerTests test = new CrashControllerTests();
test.testTriggerException();
```

## Methods
- `testTriggerException()`: Method to test the `triggerException()` method of the `CrashController` class. It triggers an exception and verifies the expected behavior.

## Useful details
- This file is associated with the `CrashController` class.
- The test class is using JUnit 5 for writing unit tests.
- The test class is used to verify the behavior of the `CrashController` class when an exception is triggered.
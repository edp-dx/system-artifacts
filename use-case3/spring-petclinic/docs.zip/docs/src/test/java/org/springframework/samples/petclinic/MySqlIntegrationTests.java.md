# MySqlIntegrationTests.java
## Overview
The `MySqlIntegrationTests` Java class contains integration tests for a Spring Boot application. It is specifically focused on testing the MySQL database integration with the application. The class is responsible for testing the functionality related to retrieving vet information and owner details from the MySQL database.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- The class has dependencies on Spring Boot, JUnit Jupiter, AssertJ, and Testcontainers.
- It requires a MySQL container to be available for testing.

## Usage
To use the `MySqlIntegrationTests` class in a project, follow these steps:
1. Ensure that the project has the necessary dependencies on Spring Boot, JUnit Jupiter, AssertJ, and Testcontainers.
2. Start a MySQL container for testing purposes.
3. Instantiate the `MySqlIntegrationTests` class and utilize its methods to test the MySQL integration functionality.

## Methods
- `testFindAll()`: This method tests the functionality of retrieving all vet information from the MySQL database. It makes use of the `vets` repository to perform the test.
- `testOwnerDetails()`: This method tests the functionality of retrieving owner details from the MySQL database. It uses a `RestTemplate` to make a request to the application running at a random port and verifies the response status.

## Useful details
- The class is annotated with `@SpringBootTest` to indicate that it is a Spring Boot test and to specify the web environment as a random port.
- It uses the `@ActiveProfiles` annotation to activate the "mysql" profile for the tests.
- Testcontainers are used to manage the MySQL container for testing purposes.
- The MySQL container version is specified as "mysql:8.2".
- The class makes use of dependency injection for `VetRepository` and `RestTemplateBuilder`.
- Some test annotations like `@DisabledInNativeImage` and `@DisabledInAotMode` are used to specify when the tests should be disabled.
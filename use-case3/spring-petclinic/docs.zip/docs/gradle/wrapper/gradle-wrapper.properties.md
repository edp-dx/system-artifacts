# gradle-wrapper.properties
## Overview
The `gradle-wrapper.properties` file is used to configure the Gradle wrapper, which is a script that invokes a declared version of Gradle, downloading it beforehand if necessary. This file specifies the distribution URL, network timeout, and other settings for the Gradle wrapper.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use the `gradle-wrapper.properties` file. However, it is important to have an understanding of Gradle and its wrapper functionality in order to effectively utilize this file.

## Usage
To use the `gradle-wrapper.properties` file in a project, it should be placed in the `gradle/wrapper` directory within the project's structure. The properties in this file can be customized to define the behavior of the Gradle wrapper. For example, to change the distribution URL to a specific version of Gradle, the `distributionUrl` property can be modified accordingly.

```properties
distributionUrl=https\://services.gradle.org/distributions/gradle-8.4-bin.zip
```

## Useful details
- `distributionBase`: Specifies the base directory for storing the Gradle distribution.
- `distributionPath`: Specifies the path within the base directory where the Gradle distribution is stored.
- `distributionUrl`: Specifies the URL from which the Gradle distribution is downloaded.
- `networkTimeout`: Specifies the timeout (in milliseconds) for network operations when downloading the Gradle distribution.
- `validateDistributionUrl`: Specifies whether to validate the distribution URL when downloading the Gradle distribution.
- `zipStoreBase`: Specifies the base directory for storing the downloaded Gradle distribution as a zip file.
- `zipStorePath`: Specifies the path within the base directory where the downloaded Gradle distribution zip file is stored.

The `gradle-wrapper.properties` file plays a crucial role in defining the behavior of the Gradle wrapper, allowing for customization of the Gradle distribution and network-related settings. It is an essential component in automating and standardizing the build process within a software project.
# build.gradle
## Overview
The `build.gradle` file is a configuration file for the Gradle build system. It is used to define the build configuration and dependencies for a software project built with Gradle.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
- Gradle build system

## Usage
To use the `build.gradle` file in a project, simply place it in the root directory of the project. The file defines the project's dependencies, plugins, and tasks, and these will be automatically picked up by the Gradle build system.

## Methods
The `build.gradle` file includes the following key sections:
- Plugins: Defines the plugins used in the project, along with their versions.
- Apply plugin: Applies the specified plugins to the project.
- Group and version: Defines the group and version of the project.
- Repositories: Specifies the Maven repository for fetching dependencies.
- Dependencies: Defines the project's dependencies, including implementation, runtime, development, and test dependencies.
- Tasks: Includes the configuration for the 'test' task, specifying the use of JUnit platform.

## Useful details
- Plugins: `java`, `org.springframework.boot`, `io.spring.dependency-management`, `org.graalvm.buildtools.native`, `io.spring.javaformat`
- Dependencies: Various Spring Boot starters, cache-api, javax.xml.bind-api, webjars for Bootstrap and Font Awesome, caffeine, H2 database, MySQL connector, PostgreSQL, Spring Boot test dependencies
- Java version: sourceCompatibility set to '17'
- Versions: `webjarsFontawesomeVersion = "4.7.0"`, `webjarsBootstrapVersion = "5.3.2"`

The `build.gradle` file plays a crucial role in defining the project's build configuration, including the required dependencies and plugins. It enables the Gradle build system to build, test, and package the project according to the specified configuration.
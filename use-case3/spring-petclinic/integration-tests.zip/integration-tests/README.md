# Integration Tests

The integration tests featured on this page have been specifically generated for your application, meticulously tailored to validate the seamless integration of its various components and modules. Here, you'll find a curated collection of tests designed to assess the interoperability of your software stack, ensuring reliability and cohesion across the system.

[Explore](/tree/gh-pages/integration-tests) integration tests to fortify your development process and enhance the resilience of your application architecture.

## Running Tests

To run all tests in this project, you'll first need to install the necessary dependencies:

```bash
pip install -r requirements.txt
```

Once the dependencies are installed, you can run the tests with the following command:

```bash
pytest
```

This command will automatically discover and run all test files in the current directory and its subdirectories.

The `pytest.ini` file in the project root directory contains configuration for pytest, including settings for the ReportPortal integration. Make sure to fill in the `rp_api_key` field with your ReportPortal API key.

# OpenAPI

Discovered OpenAPI file:

!!swagger owner-controller-openapi.yaml!!
!!swagger pet-controller-openapi.yaml!!
!!swagger vet-controller-openapi.yaml!!
!!swagger visit-controller-openapi.yaml!!

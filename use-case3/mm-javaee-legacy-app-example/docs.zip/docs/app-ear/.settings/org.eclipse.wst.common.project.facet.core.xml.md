# org.eclipse.wst.common.project.facet.core.xml
## Overview
This XML file is used in the Eclipse Web Tools Platform (WTP) project facet core. It is responsible for defining the configuration of a faceted project, including the runtime, fixed facets, and installed facets.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this XML file.

## Usage
This XML file is automatically generated and managed by the Eclipse WTP when creating or configuring a faceted project. Users do not need to directly instantiate or utilize it in their projects.

## Methods
This XML file does not contain methods or functions as it is a configuration file. However, the elements and attributes within the file serve as configuration settings for the faceted project.

## Useful details
- The `<runtime>` element specifies the name of the runtime associated with the project.
- The `<fixed>` element defines a fixed facet for the project.
- The `<installed>` element specifies an installed facet along with its version.

### CODE ###
```xml
<?xml version="1.0" encoding="UTF-8"?>
<faceted-project>
  <runtime name="JBoss 4.0 Runtime Example"/>
  <fixed facet="jst.ear"/>
  <installed facet="jst.ear" version="1.4"/>
</faceted-project>
```
### CODE ###
# Chart.yaml
## Overview
The 'Chart.yaml' file is used in Helm, a package manager for Kubernetes, to define metadata and configuration for a Helm chart. This specific file is used to define the basic information about the chart, such as its name, description, type, version, and application version.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Useful details](#properties)

## Prerequisites
No specific dependencies are required to use the 'Chart.yaml' file.

## Usage
To use the 'Chart.yaml' file in a Helm project, the user needs to define the metadata for the chart by specifying the following:
- Name of the chart
- Description of the chart
- Type of the chart (application or library)
- Version of the chart
- Application version
- Home and sources of the chart
- Maintainers of the chart

An example of using 'Chart.yaml' in a Helm project:
```yaml
apiVersion: v2
name: javaee-legacy-app-example
description: A Helm chart for Kubernetes
type: application
version: 0.1.0
appVersion: 1.16.0
home: https://github.com/edp-dx/javaee-legacy-app-example
sources:
  - https://github.com/edp-dx/javaee-legacy-app-example
maintainers:
  - name: DEV Team
```

## Useful details
The 'Chart.yaml' file serves as the entry point for defining the metadata of a Helm chart. It provides essential information about the chart, such as its version, type, and application version, which is crucial for managing and deploying applications on Kubernetes using Helm.
# _helpers.tpl
## Overview
The `_helpers.tpl` file contains a collection of reusable Go template functions for generating Kubernetes resources. These template functions are used to create default names, labels, and other metadata for various Kubernetes resources like services, service accounts, and ingresses. This file plays a crucial role in simplifying the generation of Kubernetes manifests within a Helm chart.
## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)
## Prerequisites
No specific dependencies or prerequisites are required to use the functions defined in this file.
## Usage
To use the functions defined in this file, they can be called within other Helm templates using the `{{ include "function_name" . }}` syntax.
## Methods
1. `javaee-legacy-app-example.name` - Expands the name of the chart.
2. `javaee-legacy-app-example.fullname` - Creates a default fully qualified app name.
3. `javaee-legacy-app-example.chart` - Creates chart name and version as used by the chart label.
4. `javaee-legacy-app-example.labels` - Generates common labels for Kubernetes resources.
5. `javaee-legacy-app-example.selectorLabels` - Generates selector labels for Kubernetes resources.
6. `javaee-legacy-app-example.serviceAccountName` - Creates the name of the service account to use.
7. `javaee-legacy-app-example.ingress.apiVersion` - Returns the appropriate apiVersion for ingress.
8. `javaee-legacy-app-example.ingress.isStable` - Returns if ingress is stable.
9. `javaee-legacy-app-example.ingress.supportsIngressClassName` - Returns if ingress supports ingressClassName.
10. `javaee-legacy-app-example.ingress.supportsPathType` - Returns if ingress supports pathType.
## Useful details
These template functions are designed to simplify the process of generating Kubernetes manifests within a Helm chart by providing reusable logic for creating consistent and standardized metadata. The functions take advantage of built-in Helm variables and capabilities to adapt to the specific Kubernetes environment and version.
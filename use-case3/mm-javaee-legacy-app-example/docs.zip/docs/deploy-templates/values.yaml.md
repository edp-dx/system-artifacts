# values.yaml
## Overview
The 'values.yaml' file contains default values in YAML format for the javaee-legacy-app-example. It declares variables to be passed into templates and plays a role in configuring the deployment of the Java EE legacy application example in a Kubernetes environment.
## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)
## Prerequisites
No specific dependencies or prerequisites are mentioned in the file.
## Usage
To use the values defined in this file, the user can instantiate and configure the deployment of the Java EE legacy application in a Kubernetes environment by overriding the default values as needed.
## Methods
The file does not contain methods or functions. It primarily consists of key-value pairs representing configuration settings for the deployment.
## Useful details
The file contains default values for various configuration settings such as replica count, image repository, service type, resources, autoscaling, node selector, tolerations, affinity, etc. These values can be overridden or customized as per the specific deployment requirements.
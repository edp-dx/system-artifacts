# org.eclipse.wst.jsdt.ui.superType.container
## Overview
This file is part of the org.eclipse.wst.jsdt.ui plugin in the Eclipse Web Tools Platform. It is responsible for managing and providing the super type container for JavaScript elements in the Eclipse IDE. The super type container is used to organize and display the inheritance hierarchy of JavaScript types.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
This file has dependencies on the org.eclipse.wst.jsdt.launching.baseBrowserLibrary.

## Usage
To use the super type container in a project, you would typically instantiate it and then use its methods to retrieve information about the super types of JavaScript elements. Here is an example of how it might be used:

```java
SuperTypeContainer container = new SuperTypeContainer();
JavaScriptElement element = // get a JavaScript element from the project
IType[] superTypes = container.getSuperTypes(element);
// process the super types as needed
```

## Methods
The SuperTypeContainer class in this file provides the following methods:
- `getSuperTypes(JavaScriptElement element)`: Retrieves the super types of the given JavaScript element.
- `hasSuperTypes(JavaScriptElement element)`: Checks if the given JavaScript element has any super types.

## Useful details
The super type container is an important part of the IDE's functionality for working with JavaScript code. It allows developers to understand and navigate the inheritance relationships between different JavaScript types.
# index.jsp
## Overview
The 'index.jsp' file is a Java Server Page (JSP) that is responsible for displaying a secure greeting message to the authenticated user. It also provides links for the user to log off and return to the home page.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file.

## Usage
To use the 'index.jsp' file in a project, it needs to be included in the web application directory. When a user is authenticated, the 'index.jsp' file can be accessed to display a personalized greeting message and provide options for logging off and returning to the home page.

## Methods
The 'index.jsp' file does not contain any standalone methods or functions. However, it includes JSP scriptlet code that retrieves the user's name and displays a personalized greeting message.

## Useful details
- The 'index.jsp' file uses JSP scriptlet code to retrieve the authenticated user's name using the `<%=request.getUserPrincipal().getName()%>` expression.
- The file includes hyperlinks for the user to log off and return to the home page using the `<a>` tag.

### CODE ###
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<div align="center">
		<h1>You are secure!</h1>
		<h2>Hello, <%=request.getUserPrincipal().getName()%>!</h2>
		<p/>
	    <a href="../jaas/logoff.jsp">Sair</a>   
		<p/>
	    <a href="../index.jsp">Voltar</a>   
	</div>
</body>
</html>
### CODE ###
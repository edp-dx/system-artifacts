# login_error.jsp
## Overview
The login_error.jsp file is a JSP (JavaServer Pages) file that is responsible for displaying an error message to the user in case of a login error. It provides a simple HTML structure with a heading and a link to redirect the user back to the login page.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file.

## Usage
The login_error.jsp file can be included in a web application project and linked to the login functionality. When a login error occurs, this file can be used to display a user-friendly error message to the user.

## Methods
There are no specific methods or functions in this file.

## Useful details
- The file uses JSP syntax to embed Java code within the HTML structure.
- It includes a link to redirect the user back to the login page using the anchor tag (\<a\>).

### CODE ###
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

	<div align="center">
		<h1>Error</h1>
		<p/>
	    <a href="index.jsp">Voltar</a>
	</div>

</body>
</html>
### CODE ###
# logoff.jsp
## Overview
The 'logoff.jsp' file is a JavaServer Pages (JSP) file used for logging out a user from the system. It invalidates the user's session and redirects them to the login page of the application.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use the 'logoff.jsp' file.

## Usage
To use the 'logoff.jsp' file in a project, simply include it in the project's web application directory and configure the application to handle the logout process by redirecting to this JSP file.

## Methods
- No specific methods are defined in the 'logoff.jsp' file. It contains inline Java code that performs the logout functionality.
- The main functionality of the file involves logging the user out, invalidating the session, and redirecting the user to the login page.

## Useful details
- The file uses JSP scriptlet tags (<% %>) to embed Java code within the HTML markup.
- It retrieves the user's name using the request object and logs the logout event using JBoss logging.
- It sets the appropriate cache-control headers to prevent caching of the page.
- It invalidates the user's session using request.getSession().invalidate().
- It then constructs the context path and uses JavaScript to redirect the user to the index.jsp page.

### CODE ###
```jsp
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	org.jboss.logging.Logger.getLogger(this.getClass()).warn("Logout: Usuário " + request.getUserPrincipal().getName().toString() + " acessou página logoff.jsp");
	response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
	response.setHeader("Pragma", "no-cache");
	response.setDateHeader("Expiresponse", 0);
	request.getSession().invalidate();
	String context = request.getContextPath();
	%>
	<script>
		top.document.location="<%=context%>/index.jsp";
	</script>
</body>
</html>
```
### CODE ###
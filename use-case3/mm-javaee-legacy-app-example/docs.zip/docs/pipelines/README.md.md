# README.md
## Overview
This README file provides instructions on how to run a Tekton pipeline in a software project. It includes details on the prerequisites, usage, methods, and useful details for running the pipeline.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites mentioned in this file.

## Usage
To run the Tekton pipeline, follow these steps:
1. Add logic to **build.yaml**
2. Apply the build.yaml file:
   ```bash
   kubectl apply -f build.yaml
   ```
3. Run the pipeline either through the Headlamp UI or by using the following command:
   ```bash
   kubectl apply -f pipelinerun.yaml
   ```

## Methods
There are no specific methods or functions described in this file.

## Useful details
No additional details are provided in this file.
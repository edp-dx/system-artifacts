# build.yaml
## Overview
The 'build.yaml' file is a configuration file that defines a Tekton Pipeline for building a legacy Java application. It specifies the tasks, parameters, and logic for fetching the codebase, initiating values, creating an ECR repository, building a Docker image using Kaniko, tagging the codebase, and updating CBIS.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites listed in the file itself.

## Usage
To use the 'build.yaml' file in a project, it needs to be integrated with a Tekton pipeline system. The pipeline can be triggered manually or through an automated process, and it will execute the defined tasks to build the legacy Java application.

## Methods
The file defines a Tekton Pipeline with the following tasks:
- fetch-repository: Fetches the codebase from the specified git source URL and revision.
- init-values: Initializes values for the codebase name and branch name.
- get-version: Retrieves the version information for the codebase branch.
- create-ecr-repository: Creates an ECR repository for the codebase.
- kaniko-build: Builds a Docker image using Kaniko.
- git-tag: Tags the codebase in the git repository.
- update-cbis: Updates the CBIS with the image tag and name.

Each task has specific parameters and dependencies, and they are executed in a defined sequence to build and tag the legacy Java application.

## Useful details
- The 'finally' section specifies a task 'update-cbb' that is triggered when the pipeline status is 'Succeeded'. This task updates the codebase branch name and current build number.
- The 'params' section defines default values and descriptions for various parameters used in the tasks, such as pipeline URL, git source URL, git source revision, codebase name, and codebase branch name.
- The 'workspaces' section specifies the shared workspace and SSH credentials workspace used by the tasks for accessing and working with the codebase and Docker image.

The provided code example is a YAML configuration defining a Tekton Pipeline, including tasks, parameters, and logic for building a legacy Java application.
# org.eclipse.wst.common.project.facet.core.xml
## Overview
The 'org.eclipse.wst.common.project.facet.core.xml' file is an XML file used to define the facets and runtime for a faceted project in the Eclipse Web Tools Platform (WTP). It specifies the runtime, fixed facets, and installed facets for a particular project.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#properties)

## Prerequisites
There are no specific dependencies or prerequisites required to use this file.

## Usage
To use this file in a project, it needs to be created and configured according to the specific requirements of the project. It is typically used within the context of an Eclipse WTP project to define the facets and runtime. An example of the content of the file is provided below:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<faceted-project>
  <runtime name="JBoss 4.0 Runtime Example"/>
  <fixed facet="jst.ejb"/>
  <fixed facet="java"/>
  <installed facet="jst.ejb" version="2.1"/>
  <installed facet="java" version="1.6"/>
</faceted-project>
```

## Methods
This XML file does not contain methods or functions in the traditional sense. However, it defines elements and attributes that specify the runtime and facets for a project. 

## Useful details
- The `<runtime>` element specifies the name of the runtime to be used in the project.
- The `<fixed>` elements define the facets that are fixed and cannot be changed for the project.
- The `<installed>` elements specify the facets that are installed with their respective versions.
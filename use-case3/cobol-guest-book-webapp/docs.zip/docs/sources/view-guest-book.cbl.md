# view-guest-book.cbl
## Overview
`view-guest-book.cbl` is a COBOL program designed to display the current contents of a guest book table from a database on a web page. The code is structured to connect to a PostgreSQL database, retrieve guest book entries, and format these entries in HTML to be presented on a webpage. It is likely part of a larger web application project that allows users to sign and view a digital guest book.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#useful-details)

## Prerequisites
- A COBOL runtime environment such as GnuCOBOL.
- Access to a PostgreSQL database server.
- The database `guestbookdb` should exist with the necessary schema.
- The `esqloc` precompiler for SQL statements in COBOL.
- Proper database connection credentials (replaced in the `BUFFER` string within the code).

## Usage
To utilize this program in a project, compile it using a COBOL compiler that supports embedded SQL, such as GnuCOBOL. Before running the program, ensure that the database connection string in the `BUFFER` variable is properly configured with the correct server address, port, database name, user ID, and password.

Once the program is compiled and the environment is set up, it can be executed. The program will output HTML content that can be integrated into a web server's response to display the guest book entries.

## Methods
- `sqlstate-check`: A section of the program that checks the SQL state after each SQL operation. It displays error or warning messages based on the SQL state and SQL code returned from the database operations.

## Useful details
- SQL operations are performed using embedded SQL within the COBOL code. The `EXEC SQL` statements are used to declare variables, connect to the database, and perform queries.
- HTML output is generated using `DISPLAY` statements to construct the structure of a webpage. This includes setting the MIME type as `text/html`, writing the HTML doctype, head, and body elements, and formatting the guest book entries in an HTML table.
- The database connection information is hardcoded in the program. This should ideally be read from a configuration file or environment variables to avoid security risks and improve flexibility.
- The program contains a `TODO` comment indicating that the database connection string should not be hardcoded, and this aspect of the program should be improved.
- A cursor named `CUR_ALL` is declared for iterating through the guest book entries in the database.
- The program displays a link to the COBOL source code on GitHub, suggesting that the project is open source.
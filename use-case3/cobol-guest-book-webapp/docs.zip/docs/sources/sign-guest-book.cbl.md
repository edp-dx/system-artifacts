# sign-guest-book.cbl
## Overview
The `sign-guest-book.cbl` file is a COBOL program designed to process form submissions from an HTML guest book page. The primary functionality of this program is to receive a POST request from a web form, validate the input, and insert the guest book entry into a database if the validation passes. The program includes a simple bot-deterrent mechanism by checking the answer to a math question and ensures that the comment field is populated before proceeding with the database insertion. The program also returns an HTML response indicating the status of the guest book signing and provides links for the user to sign the guest book again or view its contents.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#useful-details)

## Prerequisites
- A COBOL runtime environment capable of executing the program.
- Database connectivity libraries for COBOL to interact with a PostgreSQL database.
- An HTTP server configured to execute COBOL CGI programs.
- A configured PostgreSQL database with the appropriate `GUEST_ENTRY` table structure.

## Usage
The program is designed to be run as a CGI script on a web server. When a web form from a guest book page submits a POST request to the server, this script is executed. The server must be configured to handle CGI scripts written in COBOL, and the script must have the appropriate permissions to execute.

## Methods
The main procedures within the `sign-guest-book.cbl` program are:

- `process-new-entry`: Handles the processing of the POST request. It validates the answer to the math question and checks if the comment field is populated. If valid, it proceeds to call `insert-into-database`.

- `insert-into-database`: Establishes a connection to the PostgreSQL database using hardcoded connection details (which should be read from a configuration file instead) and inserts a new guest book entry with the provided name, email, and comment.

- `sqlstate-check`: Checks the SQL state after database operations. It provides error or warning messages based on the SQL return codes and stops the program if a severe error is encountered.

## Useful details
The program uses the `TRIM` function to check for empty input fields and replaces potentially harmful characters ("<", ">", "&") with spaces to prevent HTML or SQL injection attacks. It also uses `html-decode` to ensure that text input is correctly formatted for HTML display.

### Note on Security
The program contains hardcoded database connection strings, which is not a security best practice. In a production environment, these should be stored securely and read from a configuration file or environment variable.

### Note on Error Handling
The program performs basic error handling by displaying error messages and stopping execution if a severe database error occurs. This could be further enhanced to handle errors more gracefully in a user-facing application.

### Note on HTML Content
The program outputs HTML content directly from COBOL, which is not typical for modern web applications. In a contemporary setting, one would use a template engine or a web framework to separate the presentation and business logic layers.
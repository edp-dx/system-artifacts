# web-helpers.cbl
## Overview
The `web-helpers.cbl` file provides utility functions for handling web-related string data in COBOL programs. It contains two primary functions: `get-param-value` and `html-decode`. The `get-param-value` function is designed to parse key-value pairs from a URL query string or POST data and return the value associated with a specified key. The `html-decode` function converts HTML-encoded strings back into their original characters, replacing encoded entities with their respective symbol. Both functions help facilitate the processing of web data within COBOL applications, which might be part of a larger system that interacts with web services or handles web form submissions.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#useful-details)

## Prerequisites
- A COBOL compiler that supports the features used in the code (e.g., inline `PERFORM` and `FUNCTION` statements).
- The code may have dependencies on a build and deployment script (referenced as `./build_and_deploy.sh`), which suggests the need for a server or environment where the COBOL code can be executed and potentially integrated into web services.

## Usage
To utilize the functions in a COBOL program, the programmer must copy the functions into their project or include this file in their project's build process. Once included, the functions can be invoked with the required parameters to perform their respective tasks.

### Example Usage of `get-param-value`
```cobol
   move "param1=value1 param2=value2" to ws-query-string
   move "param1" to ws-search-key
   call "get-param-value" using ws-query-string ws-search-key returning ws-found-value
```

### Example Usage of `html-decode`
```cobol
   move "Hello%2C+World%21" to ws-html-encoded-string
   call "html-decode" using ws-html-encoded-string returning ws-html-decoded-string
```

## Methods

### `get-param-value`
This function parses a string containing key-value pairs and returns the value associated with a given key. If the key is not found, it returns a space.

**Parameters:**
- `l-raw-map-string`: The input string containing key-value pairs.
- `l-param-search-key`: The key for which the value is to be searched.
- `l-found-value`: The value returned by the function, if the key is found.

### `html-decode`
This function replaces HTML-encoded character sequences in a string with their respective symbols. It has limited support for character conversions and explicitly disallows certain characters, such as `<` and `>`.

**Parameters:**
- `l-html-encoded-string`: The HTML-encoded input string.
- `l-html-decoded-string`: The decoded string returned by the function.

## Useful details
- The `get-param-value` function uses a space to separate key-value pairs and an equals sign `=` to separate keys from values.
- The `html-decode` function currently has a limited set of supported characters. It is noted in the code that the conversion of `<` and `>` characters to a space is intentional to disallow these characters.
- Both functions use local storage and working storage sections to define necessary variables and constants.
- The maximum number of keys supported by `get-param-value` is defined by `ws-max-keys`. The maximum string length supported by `html-decode` is defined by `ws-max-string-length`.
- It is important to note the last modification dates for the functions, which are 2021-03-25 for `get-param-value` and 2021-03-24 for `html-decode`, indicating that the code may need reviewing for updates or additional functionality.
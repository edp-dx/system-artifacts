# build_and_deploy.sh

## Overview

The `build_and_deploy.sh` script is a Bash shell script designed to automate the process of building and deploying a guest book application written in COBOL. The script handles precompiling COBOL source files with embedded SQL (esqlOC), compiling them into executables, and then optionally deploying these executables to the appropriate directories on a web server. This script is likely part of a larger project where COBOL is used to generate Common Gateway Interface (CGI) executables for web applications.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#useful-details)

## Prerequisites

- Unix-like operating system with a Bash shell.
- GNU COBOL compiler (`cobc`) installed.
- ESQL precompiler (`esqlOC`) installed.
- Dependencies for `esqlOC`, such as the `unixodbc` package and PostgreSQL ODBC library.
- Sudo or root access to copy files to `/var/www/html` and `/usr/lib/cgi-bin` directories.
- The source files `view-guest-book.cbl` and `sign-guest-book.cbl`, along with any other required COBOL source files, must be present in the same directory as the script.

## Usage

To use the `build_and_deploy.sh` script:

1. Ensure all prerequisites are met and the script has execute permissions:
   ```bash
   chmod +x build_and_deploy.sh
   ```
2. Run the script from the command line:
   ```bash
   ./build_and_deploy.sh
   ```
3. The script will precompile, compile, and optionally deploy the guest book application.

## Methods

The script doesn't define functions (or "methods") in the traditional sense, as it's a linear script without reusable components. However, it performs the following steps:

- Precompiles COBOL source files with embedded SQL using `esqlOC`.
- Compiles the precompiled COBOL files into CGI executables using `cobc`.
- Copies the CGI executables and HTML files to the web server directories if deployment is enabled.

## Useful details

- The `DEPLOY_CODE` variable controls whether the deployment step is performed. Setting it to `true` enables the deployment, and any other value skips the deployment process.
- The `HTML_DEST_DIR` and `CGI_BIN_DEST_DIR` variables define the destination directories for the HTML and CGI files on the web server.
- The script creates a `generated_sources` directory to store precompiled source files and a `bin` directory for the compiled executables.
- It uses verbose output for several commands (`-v` flag) to provide detailed information during the build process.
- The build date is captured and displayed, which can be useful for logging or debugging purposes.

Here is an example of the deployment output when `DEPLOY_CODE` is set to `true`:

```bash
*****************************************************************
*                                                               *
* Deploying to local web server directories                     *
*                                                               *
*****************************************************************
'/path/to/bin/view-guest-book.cgi' -> '/usr/lib/cgi-bin/view-guest-book.cgi'
'/path/to/bin/sign-guest-book.cgi' -> '/usr/lib/cgi-bin/sign-guest-book.cgi'
'/path/to/html/index.html' -> '/var/www/html/index.html'
```

This output shows that the CGI executables and HTML files are successfully copied to their respective destination directories on the web server.
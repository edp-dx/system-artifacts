# sign-guest-book.html

## Overview
The `sign-guest-book.html` file is an HTML document that is part of a web application written to demonstrate GnuCOBOL's capabilities in handling CGI scripts. This particular file provides the interface for users to sign a virtual guest book. It includes a form that collects the user's name, email address, and comment. The form also contains a simple math captcha to prevent automated spam. Upon submission, the form data is sent to a server-side CGI script (`sign-guest-book.cgi`) for processing.

This webpage is likely part of a larger project that showcases how COBOL can be integrated with modern web technologies to create dynamic web applications. It serves as a front-end component allowing users to interact with the back-end COBOL application.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Usage](#usage)
3. [Methods](#methods)
4. [Useful details](#useful-details)

## Prerequisites
- A web server capable of serving HTML files.
- A CGI-capable server configured to handle `.cgi` scripts, specifically `sign-guest-book.cgi`.
- A GnuCOBOL environment set up on the server to run the COBOL scripts.

## Usage
To use `sign-guest-book.html` within a web application, follow these steps:
1. Place the `sign-guest-book.html` file in the appropriate directory on your web server.
2. Ensure that the `sign-guest-book.cgi` script is correctly installed and configured to handle form submissions on the server.
3. Access the `sign-guest-book.html` page through a web browser by navigating to the corresponding URL where the file is hosted.
4. The user can then fill out the form fields and submit the form to sign the guest book.

An example URL to access the page could be:
```
http://www.example.com/sign-guest-book.html
```

## Methods
There are no JavaScript methods or functions within this HTML file, as it is purely a static form document.

## Useful details
- The HTML form uses a `post` method to send data to the server, which is a standard practice for form submissions that result in a change on the server (such as adding a new entry to a guest book).
- The action attribute of the form element indicates the URL of the CGI script that will process the form submission. The server must be configured to execute this script upon request.
- The math captcha ("What is five times four?") is a simple mechanism intended to differentiate human users from bots. The server-side script would typically validate the answer before accepting the form submission.
- Styling is minimal and defined within the file itself. For a production application, it would be better to move styling to a separate CSS file.
- The link to the COBOL source code suggests that the application is open source and the back-end code is available on GitHub for review or contribution.

Remember to replace the server URLs and paths with the appropriate ones for your specific deployment.